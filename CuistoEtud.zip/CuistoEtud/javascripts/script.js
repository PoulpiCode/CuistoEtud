
  document.addEventListener("DOMContentLoaded", function () {
    // Ajoutez un gestionnaire d'événements au lien "Nous contacter"
    document.querySelector('a[href="#réseaux"]').addEventListener('click', function (e) {
      e.preventDefault(); // Empêche le comportement de lien par défaut

      // Obtient la position de la section "réseaux"
      const targetSection = document.getElementById("reseau");
      targetSection.scrollBy({ top: 500, left: 1, behavior: "smooth" });
    

      // Défilement en douceur vers la section "réseaux"
    });
  });

